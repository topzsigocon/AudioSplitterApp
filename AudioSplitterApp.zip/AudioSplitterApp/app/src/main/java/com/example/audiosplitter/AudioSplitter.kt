package com.example.audiosplitter

import android.content.Context
import android.media.*
import android.net.Uri
import java.io.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.log10
import kotlin.math.sqrt

/** Impormasyon ng decoded PCM (16-bit, interleaved) na naka-save sa temp file. */
data class PcmInfo(val file: File, val sampleRate: Int, val channels: Int) {
    val bytesPerFrame get() = channels * 2
    val totalFrames get() = file.length() / bytesPerFrame
}

/** Saklaw ng isang hiwa, sa "frames" (isang frame = isang sample bawat channel). */
data class Segment(val startFrame: Long, val endFrame: Long)

object AudioSplitter {

    // ---------- 1. DECODE (kahit anong format na kaya ng Android -> PCM) ----------
    fun decodeToPcm(
        context: Context, uri: Uri, tempFile: File,
        onProgress: (Float) -> Unit = {}
    ): PcmInfo {
        val ex = MediaExtractor()
        ex.setDataSource(context, uri, null)
        val track = (0 until ex.trackCount).first {
            ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/")
        }
        ex.selectTrack(track)
        val fmt = ex.getTrackFormat(track)
        val durationUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
        val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(fmt, null, null, 0)
        codec.start()

        var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false

        BufferedOutputStream(FileOutputStream(tempFile), 1 shl 16).use { out ->
            while (!outputDone) {
                if (!inputDone) {
                    val i = codec.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val buf = codec.getInputBuffer(i)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                            if (durationUs > 0) onProgress((ex.sampleTime.toFloat() / durationUs).coerceIn(0f, 1f))
                            ex.advance()
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = codec.outputFormat
                        sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                    o >= 0 -> {
                        val buf = codec.getOutputBuffer(o)!!
                        val bytes = ByteArray(info.size)
                        buf.get(bytes)
                        out.write(bytes)
                        codec.releaseOutputBuffer(o, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                    }
                }
            }
        }
        codec.stop(); codec.release(); ex.release()
        return PcmInfo(tempFile, sr, ch)
    }

    // ---------- 2. AUTOMATIC NA PAGHANAP NG TAHIMIK NA PARTE ----------
    /**
     * @param thresholdDb   Hanggang saan itinuturing na "tahimik" (hal. -40 dB). Mas mababa = mas mahigpit.
     * @param minSilenceMs  Pinakamaikling katahimikan para ituring na hiwaan (hal. 700 ms).
     * @param minSegmentMs  Pinakamaikling hiwa; ang mas maikli ay isasama sa katabi (hal. 5000 ms).
     */
    fun detectSegments(
        pcm: PcmInfo, thresholdDb: Float = -40f,
        minSilenceMs: Int = 700, minSegmentMs: Int = 5000
    ): List<Segment> {
        val winFrames = (pcm.sampleRate * 0.02).toInt()          // 20 ms na window
        val minSilWins = minSilenceMs / 20
        val total = pcm.totalFrames
        val cuts = mutableListOf<Long>()                          // mga puntong paghihiwalay
        var silentRun = 0
        var runStartWin = 0L
        var winIndex = 0L

        val buf = ByteArray(winFrames * pcm.bytesPerFrame)
        BufferedInputStream(FileInputStream(pcm.file), 1 shl 16).use { input ->
            while (true) {
                val n = readFully(input, buf)
                if (n < pcm.bytesPerFrame) break
                val sb = ByteBuffer.wrap(buf, 0, n).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                var sum = 0.0
                val cnt = sb.remaining()
                while (sb.hasRemaining()) { val s = sb.get().toDouble(); sum += s * s }
                val rms = sqrt(sum / cnt.coerceAtLeast(1))
                val db = if (rms < 1) -96f else (20 * log10(rms / 32768.0)).toFloat()

                if (db < thresholdDb) {
                    if (silentRun == 0) runStartWin = winIndex
                    silentRun++
                } else {
                    if (silentRun >= minSilWins) cuts += (runStartWin + winIndex) / 2 * winFrames
                    silentRun = 0
                }
                winIndex++
            }
            if (silentRun >= minSilWins) cuts += (runStartWin + winIndex) / 2 * winFrames
        }
        return buildSegments(cuts, total, pcm.sampleRate, minSegmentMs)
    }

    /** Ginagamit din ng manual mode: ibigay lang ang listahan ng cut points (sa frames). */
    fun buildSegments(cuts: List<Long>, total: Long, sampleRate: Int, minSegmentMs: Int = 0): List<Segment> {
        val minFrames = sampleRate.toLong() * minSegmentMs / 1000
        val points = (listOf(0L) + cuts.sorted() + listOf(total)).distinct()
        val result = mutableListOf<Segment>()
        var start = points.first()
        for (p in points.drop(1)) {
            if (p - start >= minFrames || p == total) {
                result += Segment(start, p); start = p
            }
        }
        // kung may maiksing natira sa dulo, isama sa huling hiwa
        if (result.isNotEmpty() && result.last().endFrame != total)
            result[result.lastIndex] = result.last().copy(endFrame = total)
        return result
    }

    // ---------- Helpers: waveform peaks at safe na pagbasa ----------
    private fun readFully(input: InputStream, buf: ByteArray): Int {
        var total = 0
        while (total < buf.size) {
            val r = input.read(buf, total, buf.size - total)
            if (r < 0) break
            total += r
        }
        return total
    }

    /** Peaks ng buong file (para sa unang display). */
    fun computePeaks(pcm: PcmInfo, buckets: Int = 800): FloatArray =
        computePeaksRange(pcm, 0, pcm.totalFrames, buckets)

    /**
     * Taas ng waveform (0..1) para sa isang saklaw ng frames. Kapag naka-zoom in,
     * mas maliit ang bawat bucket kaya mas detalyado at mas tumpak ang waveform.
     */
    fun computePeaksRange(pcm: PcmInfo, startFrame: Long, endFrame: Long, buckets: Int = 800): FloatArray {
        val total = pcm.totalFrames
        val s0 = startFrame.coerceIn(0, total)
        val e0 = endFrame.coerceIn(s0, total)
        val per = ((e0 - s0) / buckets).coerceAtLeast(1)
        val peaks = FloatArray(buckets)
        RandomAccessFile(pcm.file, "r").use { raf ->
            val frames = minOf(per, 2048L).toInt()
            val buf = ByteArray(frames * pcm.bytesPerFrame)
            for (b in 0 until buckets) {
                val pos = s0 + b * per
                if (pos >= total) break
                raf.seek(pos * pcm.bytesPerFrame)
                val n = raf.read(buf)
                if (n <= 0) break
                val sb = ByteBuffer.wrap(buf, 0, n).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                var m = 0
                while (sb.hasRemaining()) { val v = kotlin.math.abs(sb.get().toInt()); if (v > m) m = v }
                peaks[b] = m / 32768f
            }
        }
        return peaks
    }

    // ---------- 3. EXPORT: AAC (.m4a) hanggang 320 kbps stereo ----------
    fun exportAac(
        pcm: PcmInfo, seg: Segment, out: File,
        bitrate: Int = 320_000, stereo: Boolean = true
    ) {
        val dstCh = if (stereo) 2 else 1
        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, pcm.sampleRate, dstCh).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 1 shl 16)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        enc.start()
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var muxTrack = -1
        val info = MediaCodec.BufferInfo()

        RandomAccessFile(pcm.file, "r").use { raf ->
            raf.seek(seg.startFrame * pcm.bytesPerFrame)
            var remaining = seg.endFrame - seg.startFrame
            var framesDone = 0L
            var inputDone = false
            var outputDone = false

            while (!outputDone) {
                if (!inputDone) {
                    val i = enc.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val ib = enc.getInputBuffer(i)!!
                        ib.clear()
                        val maxFrames = minOf(remaining, (ib.capacity() / (2 * dstCh)).toLong()).toInt()
                        val pts = framesDone * 1_000_000L / pcm.sampleRate
                        if (maxFrames <= 0) {
                            enc.queueInputBuffer(i, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            val src = ByteArray(maxFrames * pcm.bytesPerFrame)
                            raf.readFully(src)
                            val converted = convertChannels(src, pcm.channels, dstCh)
                            ib.put(converted)
                            enc.queueInputBuffer(i, 0, converted.size, pts, 0)
                            remaining -= maxFrames; framesDone += maxFrames
                        }
                    }
                }
                val o = enc.dequeueOutputBuffer(info, 10_000)
                when {
                    o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        muxTrack = muxer.addTrack(enc.outputFormat); muxer.start()
                    }
                    o >= 0 -> {
                        val ob = enc.getOutputBuffer(o)!!
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (info.size > 0 && muxTrack >= 0) {
                            ob.position(info.offset); ob.limit(info.offset + info.size)
                            muxer.writeSampleData(muxTrack, ob, info)
                        }
                        enc.releaseOutputBuffer(o, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                    }
                }
            }
        }
        enc.stop(); enc.release()
        muxer.stop(); muxer.release()
    }

    // ---------- 4. EXPORT: WAV (lossless, walang bitrate) ----------
    fun exportWav(pcm: PcmInfo, seg: Segment, out: File, stereo: Boolean = true) {
        val dstCh = if (stereo) 2 else 1
        val frames = seg.endFrame - seg.startFrame
        val dataLen = frames * dstCh * 2
        DataOutputStream(BufferedOutputStream(FileOutputStream(out))).use { o ->
            fun le32(v: Long) = o.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v.toInt()).array())
            fun le16(v: Int) = o.write(ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort(v.toShort()).array())
            o.writeBytes("RIFF"); le32(36 + dataLen); o.writeBytes("WAVEfmt ")
            le32(16); le16(1); le16(dstCh); le32(pcm.sampleRate.toLong())
            le32(pcm.sampleRate.toLong() * dstCh * 2); le16(dstCh * 2); le16(16)
            o.writeBytes("data"); le32(dataLen)
            RandomAccessFile(pcm.file, "r").use { raf ->
                raf.seek(seg.startFrame * pcm.bytesPerFrame)
                var left = frames
                val chunk = 8192
                while (left > 0) {
                    val n = minOf(left, chunk.toLong()).toInt()
                    val src = ByteArray(n * pcm.bytesPerFrame); raf.readFully(src)
                    o.write(convertChannels(src, pcm.channels, dstCh)); left -= n
                }
            }
        }
    }

    /** Mono<->Stereo conversion (16-bit little-endian interleaved). */
    private fun convertChannels(src: ByteArray, srcCh: Int, dstCh: Int): ByteArray {
        if (srcCh == dstCh) return src
        val s = ByteBuffer.wrap(src).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val frames = s.remaining() / srcCh
        val dst = ByteBuffer.allocate(frames * dstCh * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (f in 0 until frames) {
            val l = s.get(f * srcCh)
            val r = if (srcCh > 1) s.get(f * srcCh + 1) else l
            if (dstCh == 2) { dst.putShort(l); dst.putShort(r) }
            else dst.putShort(((l + r) / 2).toShort())
        }
        return dst.array()
    }
}
