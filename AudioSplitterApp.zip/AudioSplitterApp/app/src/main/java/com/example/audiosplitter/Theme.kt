package com.example.audiosplitter

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val LightColors = lightColorScheme(
    primary = Color(0xFF111111), onPrimary = Color.White,
    background = Color(0xFFFAFAFA), onBackground = Color(0xFF111111),
    surface = Color(0xFFFAFAFA), onSurface = Color(0xFF111111),
    surfaceVariant = Color(0xFFEFEFEF), onSurfaceVariant = Color(0xFF6E6E6E),
    outline = Color(0xFFBDBDBD), outlineVariant = Color(0xFFE2E2E2),
    error = Color(0xFFFF5A4D), onError = Color.White,
    secondaryContainer = Color(0xFF111111), onSecondaryContainer = Color.White
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFF2F2F2), onPrimary = Color(0xFF111111),
    background = Color(0xFF0E0F10), onBackground = Color(0xFFF2F2F2),
    surface = Color(0xFF0E0F10), onSurface = Color(0xFFF2F2F2),
    surfaceVariant = Color(0xFF1B1D1F), onSurfaceVariant = Color(0xFF9A9A9A),
    outline = Color(0xFF4A4A4A), outlineVariant = Color(0xFF2A2C2E),
    error = Color(0xFFFF5A4D), onError = Color.White,
    secondaryContainer = Color(0xFFF2F2F2), onSecondaryContainer = Color(0xFF111111)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val base = Typography()
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        shapes = Shapes(
            small = RoundedCornerShape(10.dp),
            medium = RoundedCornerShape(12.dp),
            large = RoundedCornerShape(16.dp)
        ),
        typography = base.copy(
            headlineSmall = base.headlineSmall.copy(fontWeight = FontWeight.Light, fontSize = 28.sp, letterSpacing = (-0.5).sp),
            titleMedium = base.titleMedium.copy(fontWeight = FontWeight.Normal),
            labelSmall = base.labelSmall.copy(letterSpacing = 1.2.sp)
        ),
        content = content
    )
}
