package com.example.audiosplitter

import android.content.ContentValues
import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { AppScreen() }
            }
        }
    }
}

class SegmentPlayer(private val ctx: Context) {
    private var mp: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    fun play(uri: Uri, startMs: Long, endMs: Long) {
        stop()
        mp = MediaPlayer().apply {
            setDataSource(ctx, uri); prepare(); seekTo(startMs.toInt()); start()
        }
        handler.postDelayed({ stop() }, (endMs - startMs).coerceAtLeast(100))
    }
    fun stop() { handler.removeCallbacksAndMessages(null); mp?.release(); mp = null }
}

/** Peaks na nakalkula para sa isang saklaw ng frames (start..start+len). */
class WavePeaks(val start: Long, val len: Long, val data: FloatArray)

private fun fmt(frames: Long, sr: Int): String {
    val s = frames / sr
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

private fun fmtT(frames: Long, sr: Int, precise: Boolean): String {
    if (!precise) return fmt(frames, sr)
    val ms = frames * 1000 / sr
    return "%d:%02d.%d".format(ms / 60000, (ms % 60000) / 1000, (ms % 1000) / 100)
}

private fun displayName(ctx: Context, uri: Uri): String =
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && i >= 0) c.getString(i) else null
    }?.substringBeforeLast('.') ?: "audio"

/** Isine-save sa Music/AudioSplitter (Android 10+), o sa app folder para sa mas luma. */
private fun saveToMusic(ctx: Context, src: File, name: String, mime: String) {
    if (Build.VERSION.SDK_INT >= 29) {
        val v = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, name)
            put(MediaStore.Audio.Media.MIME_TYPE, mime)
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/AudioSplitter")
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val u = ctx.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v)!!
        ctx.contentResolver.openOutputStream(u)!!.use { o -> src.inputStream().use { it.copyTo(o) } }
        v.clear(); v.put(MediaStore.Audio.Media.IS_PENDING, 0)
        ctx.contentResolver.update(u, v, null, null)
    } else {
        val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "AudioSplitter").apply { mkdirs() }
        src.copyTo(File(dir, name), overwrite = true)
    }
}

// ---------------------------------------------------------------- UI pieces

@Composable
private fun SectionLabel(text: String) =
    Text(text.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
private fun LabeledSlider(label: String, valueText: String, v: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(valueText, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
        }
        Slider(
            value = v, onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = cs.primary, activeTrackColor = cs.primary, inactiveTrackColor = cs.outlineVariant)
        )
    }
}

/**
 * Waveform na pwedeng i-zoom: pinch gamit ang dalawang daliri, at i-drag para igalaw.
 * Ang tap ay nagdadagdag/nagtatanggal ng putol.
 */
@Composable
private fun Waveform(
    wave: WavePeaks?, cuts: List<Long>, viewStart: Long, viewLen: Long,
    onTap: (Long) -> Unit, onTransform: (cx: Float, pan: Float, zoom: Float) -> Unit
) {
    val barColor = MaterialTheme.colorScheme.onSurfaceVariant
    val cutColor = MaterialTheme.colorScheme.error
    val lineColor = MaterialTheme.colorScheme.outline
    val tap by rememberUpdatedState(onTap)
    val xf by rememberUpdatedState(onTransform)
    val vs by rememberUpdatedState(viewStart)
    val vl by rememberUpdatedState(viewLen)

    Canvas(
        Modifier.fillMaxWidth().height(150.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .pointerInput(Unit) {
                detectTapGestures { off -> tap(vs + (off.x / size.width * vl).toLong()) }
            }
            .pointerInput(Unit) {
                detectTransformGestures { c, pan, zoom, _ -> xf(c.x / size.width, pan.x / size.width, zoom) }
            }
    ) {
        val w = size.width; val h = size.height
        drawLine(lineColor, Offset(0f, h / 2), Offset(w, h / 2), strokeWidth = 1f)
        wave?.let { wp ->
            val n = wp.data.size
            val binLen = wp.len.toFloat() / n
            val barW = binLen / viewLen * w
            wp.data.forEachIndexed { i, p ->
                val x = (wp.start + i * binLen - viewStart) / viewLen * w
                if (x + barW >= 0f && x <= w) {
                    val ph = (kotlin.math.sqrt(p) * h * 0.92f).coerceAtLeast(2f)
                    val cx = x + barW / 2
                    drawLine(barColor, Offset(cx, (h - ph) / 2), Offset(cx, (h + ph) / 2),
                        strokeWidth = (barW * 0.7f).coerceAtLeast(1f))
                }
            }
        }
        cuts.forEach { c ->
            val x = (c - viewStart).toFloat() / viewLen * w
            if (x in 0f..w) {
                drawLine(cutColor, Offset(x, 0f), Offset(x, h), strokeWidth = 3f)
                drawCircle(cutColor, 7f, Offset(x, 7f))
            }
        }
    }
}

// ---------------------------------------------------------------- Main screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme

    var uri by remember { mutableStateOf<Uri?>(null) }
    var baseName by remember { mutableStateOf("") }
    var pcm by remember { mutableStateOf<PcmInfo?>(null) }
    var wave by remember { mutableStateOf<WavePeaks?>(null) }
    var viewStart by remember { mutableStateOf(0L) }
    var viewLen by remember { mutableStateOf(1L) }
    val cuts = remember { mutableStateListOf<Long>() }

    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    var status by remember { mutableStateOf("Pumili ng audio file para magsimula.") }

    var thresholdDb by remember { mutableStateOf(-40f) }
    var minSilenceMs by remember { mutableStateOf(700f) }
    var minSegmentSec by remember { mutableStateOf(5f) }
    var bitrate by remember { mutableStateOf(320) }
    var stereo by remember { mutableStateOf(true) }
    var wav by remember { mutableStateOf(false) }

    val player = remember { SegmentPlayer(ctx) }
    DisposableEffect(Unit) { onDispose { player.stop() } }

    // Ayusin ang view (zoom/pan) nang hindi lumalampas sa file.
    fun setView(start: Long, len: Long) {
        val info = pcm ?: return
        val total = info.totalFrames
        val minLen = minOf(total, info.sampleRate / 2L)
        val l = len.coerceIn(minLen, total)
        viewLen = l
        viewStart = start.coerceIn(0L, total - l)
    }
    fun zoomBy(factor: Float) {
        val center = viewStart + viewLen / 2
        val newLen = (viewLen / factor).toLong().coerceAtLeast(1)
        setView(center - newLen / 2, newLen)
    }

    // Kalkulahin ulit ang waveform pagkatapos mag-zoom/pan (may kaunting antala para hindi mabigat).
    LaunchedEffect(pcm, viewStart, viewLen) {
        val info = pcm ?: return@LaunchedEffect
        val s = viewStart; val l = viewLen
        val cur = wave
        if (cur != null && cur.start == s && cur.len == l) return@LaunchedEffect
        delay(150)
        val d = withContext(Dispatchers.Default) { AudioSplitter.computePeaksRange(info, s, s + l, 800) }
        wave = WavePeaks(s, l, d)
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            player.stop()
            uri = u; baseName = displayName(ctx, u); cuts.clear(); pcm = null; wave = null
            busy = true; progress = 0f; status = "Binabasa ang file…"
            scope.launch {
                try {
                    val info = withContext(Dispatchers.Default) {
                        AudioSplitter.decodeToPcm(ctx, u, File(ctx.cacheDir, "decoded.pcm")) { progress = it }
                    }
                    viewStart = 0L; viewLen = info.totalFrames.coerceAtLeast(1)
                    pcm = info
                    status = "${fmt(info.totalFrames, info.sampleRate)} · ${info.sampleRate} Hz · ${if (info.channels == 1) "mono" else "stereo"}"
                } catch (e: Exception) {
                    status = "Hindi mabasa ang file: ${e.message}"
                }
                busy = false
            }
        }
    }

    val p = pcm
    val segments = if (p != null) AudioSplitter.buildSegments(cuts.toList(), p.totalFrames, p.sampleRate) else emptyList()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Audio Splitter", style = MaterialTheme.typography.headlineSmall)
            if (baseName.isNotEmpty()) Text(baseName, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, maxLines = 1)
            Text(status, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        if (busy) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = cs.primary, trackColor = cs.outlineVariant)

        Button(onClick = { picker.launch(arrayOf("audio/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
            Text(if (p == null) "Pumili ng audio file" else "Palitan ang file")
        }

        if (p != null) {
            HorizontalDivider(color = cs.outlineVariant)

            // ---------- Waveform ----------
            SectionLabel("Waveform")
            Waveform(
                wave = wave, cuts = cuts, viewStart = viewStart, viewLen = viewLen,
                onTap = { frame ->
                    val near = viewLen * 0.015
                    val hit = cuts.firstOrNull { kotlin.math.abs(it - frame) < near }
                    if (hit != null) cuts.remove(hit) else if (frame in 1 until p.totalFrames) cuts.add(frame)
                },
                onTransform = { cx, pan, zoom ->
                    val anchor = viewStart + (cx * viewLen).toLong()
                    val newLen = (viewLen / zoom).toLong().coerceAtLeast(1)
                    setView(anchor - (cx * newLen).toLong() - (pan * newLen).toLong(), newLen)
                }
            )
            val precise = viewLen < 120L * p.sampleRate
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmtT(viewStart, p.sampleRate, precise), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                Text("×%.1f".format(p.totalFrames.toFloat() / viewLen), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                Text(fmtT(viewStart + viewLen, p.sampleRate, precise), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            if (viewLen < p.totalFrames) {
                Slider(
                    value = viewStart.toFloat() / (p.totalFrames - viewLen).coerceAtLeast(1),
                    onValueChange = { setView(((p.totalFrames - viewLen) * it).toLong(), viewLen) },
                    colors = SliderDefaults.colors(thumbColor = cs.primary, activeTrackColor = cs.outlineVariant, inactiveTrackColor = cs.outlineVariant)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { zoomBy(1 / 2f) }) { Text("−") }
                OutlinedButton(onClick = { zoomBy(2f) }) { Text("+") }
                TextButton(onClick = { setView(0L, p.totalFrames) }) { Text("Buong tanaw") }
            }
            Text("Pinch para mag-zoom, i-drag para gumalaw. I-tap ang waveform para magdagdag ng putol; i-tap ulit malapit sa pulang linya para tanggalin.",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)

            HorizontalDivider(color = cs.outlineVariant)

            // ---------- Auto-detect ----------
            SectionLabel("Auto-detect ng katahimikan")
            LabeledSlider("Threshold", "${thresholdDb.toInt()} dB", thresholdDb, -70f..-20f) { thresholdDb = it }
            LabeledSlider("Minimum na katahimikan", "${minSilenceMs.toInt()} ms", minSilenceMs, 200f..3000f) { minSilenceMs = it }
            LabeledSlider("Minimum na haba ng hiwa", "${minSegmentSec.toInt()} s", minSegmentSec, 0f..60f) { minSegmentSec = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = !busy, onClick = {
                    busy = true; status = "Hinahanap ang mga tahimik na parte…"
                    scope.launch {
                        val segs = withContext(Dispatchers.Default) {
                            AudioSplitter.detectSegments(p, thresholdDb, minSilenceMs.toInt(), (minSegmentSec * 1000).toInt())
                        }
                        cuts.clear(); cuts.addAll(segs.drop(1).map { it.startFrame })
                        status = "Nakahanap ng ${segs.size} hiwa."
                        busy = false
                    }
                }) { Text("Auto-detect") }
                OutlinedButton(onClick = { cuts.clear() }, enabled = !busy) { Text("Burahin ang putol") }
            }

            HorizontalDivider(color = cs.outlineVariant)

            // ---------- Output ----------
            SectionLabel("Output")
            val chipColors = FilterChipDefaults.filterChipColors(selectedContainerColor = cs.primary, selectedLabelColor = cs.onPrimary)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(!wav, { wav = false }, label = { Text("M4A (AAC)") }, colors = chipColors)
                FilterChip(wav, { wav = true }, label = { Text("WAV") }, colors = chipColors)
            }
            if (!wav) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(128, 192, 256, 320).forEach { b ->
                        FilterChip(bitrate == b, { bitrate = b }, label = { Text("$b") }, colors = chipColors)
                    }
                    Text("kbps", Modifier.align(Alignment.CenterVertically), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(
                    stereo, { stereo = it },
                    colors = SwitchDefaults.colors(checkedTrackColor = cs.primary, checkedThumbColor = cs.onPrimary)
                )
                Spacer(Modifier.width(12.dp)); Text(if (stereo) "Stereo" else "Mono")
            }

            HorizontalDivider(color = cs.outlineVariant)

            // ---------- Mga hiwa ----------
            SectionLabel("Mga hiwa · ${segments.size}")
            segments.forEachIndexed { i, s ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("%02d".format(i + 1), color = cs.onSurfaceVariant, modifier = Modifier.width(32.dp))
                    Column(Modifier.weight(1f)) {
                        Text("${fmt(s.startFrame, p.sampleRate)} – ${fmt(s.endFrame, p.sampleRate)}")
                        Text(fmt(s.endFrame - s.startFrame, p.sampleRate), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                    TextButton(onClick = {
                        uri?.let { player.play(it, s.startFrame * 1000 / p.sampleRate, s.endFrame * 1000 / p.sampleRate) }
                    }) { Text("▶") }
                }
            }
            if (segments.isNotEmpty()) TextButton(onClick = { player.stop() }) { Text("■ Itigil ang playback") }

            Button(
                modifier = Modifier.fillMaxWidth(),
                enabled = !busy && segments.isNotEmpty(),
                onClick = {
                    player.stop(); busy = true; progress = 0f
                    scope.launch {
                        try {
                            withContext(Dispatchers.Default) {
                                segments.forEachIndexed { i, s ->
                                    status = "Ine-export ang hiwa ${i + 1} ng ${segments.size}…"
                                    val ext = if (wav) "wav" else "m4a"
                                    val tmp = File(ctx.cacheDir, "seg.$ext")
                                    if (wav) AudioSplitter.exportWav(p, s, tmp, stereo)
                                    else AudioSplitter.exportAac(p, s, tmp, bitrate * 1000, stereo)
                                    saveToMusic(ctx, tmp, "%s_%03d.%s".format(baseName, i + 1, ext),
                                        if (wav) "audio/x-wav" else "audio/mp4")
                                    tmp.delete()
                                    progress = (i + 1f) / segments.size
                                }
                            }
                            status = "Tapos na. ${segments.size} file sa Music/AudioSplitter."
                        } catch (e: Exception) {
                            status = "May error sa pag-export: ${e.message}"
                        }
                        busy = false
                    }
                }
            ) { Text("I-export ang ${segments.size} hiwa") }
            Spacer(Modifier.height(16.dp))
        }
    }
}
