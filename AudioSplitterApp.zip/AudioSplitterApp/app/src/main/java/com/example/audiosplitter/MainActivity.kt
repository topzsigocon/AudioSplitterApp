package com.example.audiosplitter

import android.content.ContentValues
import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { AppScreen() } } }
    }
}

class SegmentPlayer(private val ctx: Context) {
    private var mp: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    fun play(uri: Uri, startMs: Long, endMs: Long) {
        stop()
        mp = MediaPlayer().apply {
            setDataSource(ctx, uri); prepare(); seekTo(startMs.toInt()); start()
        }
        handler.postDelayed({ stop() }, (endMs - startMs).coerceAtLeast(100))
    }
    fun stop() { handler.removeCallbacksAndMessages(null); mp?.release(); mp = null }
}

private fun fmt(frames: Long, sr: Int): String {
    val s = frames / sr
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

private fun displayName(ctx: Context, uri: Uri): String =
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && i >= 0) c.getString(i) else null
    }?.substringBeforeLast('.') ?: "audio"

/** Sine-save sa Music/AudioSplitter (Android 10+), o sa app folder para sa mas luma. */
private fun saveToMusic(ctx: Context, src: File, name: String, mime: String) {
    if (Build.VERSION.SDK_INT >= 29) {
        val v = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, name)
            put(MediaStore.Audio.Media.MIME_TYPE, mime)
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/AudioSplitter")
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val u = ctx.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v)!!
        ctx.contentResolver.openOutputStream(u)!!.use { o -> src.inputStream().use { it.copyTo(o) } }
        v.clear(); v.put(MediaStore.Audio.Media.IS_PENDING, 0)
        ctx.contentResolver.update(u, v, null, null)
    } else {
        val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "AudioSplitter").apply { mkdirs() }
        src.copyTo(File(dir, name), overwrite = true)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var uri by remember { mutableStateOf<Uri?>(null) }
    var baseName by remember { mutableStateOf("audio") }
    var pcm by remember { mutableStateOf<PcmInfo?>(null) }
    var peaks by remember { mutableStateOf(FloatArray(0)) }
    val cuts = remember { mutableStateListOf<Long>() }

    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    var status by remember { mutableStateOf("Pumili ng audio file para magsimula.") }

    var thresholdDb by remember { mutableStateOf(-40f) }
    var minSilenceMs by remember { mutableStateOf(700f) }
    var minSegmentSec by remember { mutableStateOf(5f) }
    var bitrate by remember { mutableStateOf(320) }
    var stereo by remember { mutableStateOf(true) }
    var wav by remember { mutableStateOf(false) }

    val player = remember { SegmentPlayer(ctx) }
    DisposableEffect(Unit) { onDispose { player.stop() } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            player.stop()
            uri = u; baseName = displayName(ctx, u); cuts.clear(); pcm = null
            busy = true; progress = 0f; status = "Binabasa ang file…"
            scope.launch {
                try {
                    val info = withContext(Dispatchers.Default) {
                        AudioSplitter.decodeToPcm(ctx, u, File(ctx.cacheDir, "decoded.pcm")) { progress = it }
                    }
                    peaks = withContext(Dispatchers.Default) { AudioSplitter.computePeaks(info) }
                    pcm = info
                    status = "Handa na: ${fmt(info.totalFrames, info.sampleRate)} · ${info.sampleRate} Hz · ${info.channels} ch"
                } catch (e: Exception) {
                    status = "Hindi mabasa ang file: ${e.message}"
                }
                busy = false
            }
        }
    }

    val p = pcm
    val segments = if (p != null) AudioSplitter.buildSegments(cuts.toList(), p.totalFrames, p.sampleRate) else emptyList()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Audio Splitter", style = MaterialTheme.typography.headlineSmall)
        Button(onClick = { picker.launch(arrayOf("audio/*")) }, enabled = !busy) { Text("Pumili ng audio file") }
        Text(status, style = MaterialTheme.typography.bodyMedium)
        if (busy) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())

        if (p != null) {
            // ---------- Waveform + manual cuts ----------
            Text("Waveform — i-tap para magdagdag ng putol; i-tap ulit malapit sa linya para tanggalin.",
                style = MaterialTheme.typography.labelMedium)
            Waveform(peaks, cuts, p.totalFrames) { frame ->
                val near = p.totalFrames * 0.012
                val hit = cuts.firstOrNull { kotlin.math.abs(it - frame) < near }
                if (hit != null) cuts.remove(hit) else if (frame in 1 until p.totalFrames) cuts.add(frame)
            }

            // ---------- Auto-detect settings ----------
            Text("Automatic na paghanap ng katahimikan", style = MaterialTheme.typography.titleMedium)
            Text("Threshold: ${thresholdDb.toInt()} dB (mas mababa = mas mahigpit)")
            Slider(thresholdDb, { thresholdDb = it }, valueRange = -70f..-20f)
            Text("Minimum na katahimikan: ${minSilenceMs.toInt()} ms")
            Slider(minSilenceMs, { minSilenceMs = it }, valueRange = 200f..3000f)
            Text("Minimum na haba ng hiwa: ${minSegmentSec.toInt()} segundo")
            Slider(minSegmentSec, { minSegmentSec = it }, valueRange = 0f..60f)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = !busy, onClick = {
                    busy = true; status = "Hinahanap ang mga tahimik na parte…"
                    scope.launch {
                        val segs = withContext(Dispatchers.Default) {
                            AudioSplitter.detectSegments(p, thresholdDb, minSilenceMs.toInt(), (minSegmentSec * 1000).toInt())
                        }
                        cuts.clear(); cuts.addAll(segs.drop(1).map { it.startFrame })
                        status = "Nakahanap ng ${segs.size} hiwa."
                        busy = false
                    }
                }) { Text("Auto-detect") }
                OutlinedButton(onClick = { cuts.clear() }, enabled = !busy) { Text("Burahin lahat ng putol") }
            }

            // ---------- Output settings ----------
            Text("Output", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(!wav, { wav = false }, label = { Text("M4A (AAC)") })
                FilterChip(wav, { wav = true }, label = { Text("WAV") })
            }
            if (!wav) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(128, 192, 256, 320).forEach { b ->
                        FilterChip(bitrate == b, { bitrate = b }, label = { Text("$b kbps") })
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(stereo, { stereo = it })
                Spacer(Modifier.width(8.dp)); Text(if (stereo) "Stereo" else "Mono")
            }

            // ---------- Listahan ng hiwa ----------
            Text("Mga hiwa (${segments.size})", style = MaterialTheme.typography.titleMedium)
            segments.forEachIndexed { i, s ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("${i + 1}.  ${fmt(s.startFrame, p.sampleRate)} – ${fmt(s.endFrame, p.sampleRate)}",
                        Modifier.weight(1f))
                    TextButton(onClick = {
                        uri?.let { player.play(it, s.startFrame * 1000 / p.sampleRate, s.endFrame * 1000 / p.sampleRate) }
                    }) { Text("▶ Pakinggan") }
                }
            }
            TextButton(onClick = { player.stop() }) { Text("■ Itigil ang playback") }

            Button(enabled = !busy && segments.isNotEmpty(), onClick = {
                player.stop(); busy = true; progress = 0f
                scope.launch {
                    try {
                        withContext(Dispatchers.Default) {
                            segments.forEachIndexed { i, s ->
                                status = "Ine-export ang hiwa ${i + 1} ng ${segments.size}…"
                                val ext = if (wav) "wav" else "m4a"
                                val tmp = File(ctx.cacheDir, "seg.$ext")
                                if (wav) AudioSplitter.exportWav(p, s, tmp, stereo)
                                else AudioSplitter.exportAac(p, s, tmp, bitrate * 1000, stereo)
                                saveToMusic(ctx, tmp, "%s_%03d.%s".format(baseName, i + 1, ext),
                                    if (wav) "audio/x-wav" else "audio/mp4")
                                tmp.delete()
                                progress = (i + 1f) / segments.size
                            }
                        }
                        status = "Tapos na! ${segments.size} file sa Music/AudioSplitter."
                    } catch (e: Exception) {
                        status = "May error sa pag-export: ${e.message}"
                    }
                    busy = false
                }
            }) { Text("I-export ang lahat ng hiwa") }
        }
    }
}

@Composable
fun Waveform(peaks: FloatArray, cuts: List<Long>, total: Long, onTap: (Long) -> Unit) {
    val barColor = MaterialTheme.colorScheme.primary
    val cutColor = MaterialTheme.colorScheme.error
    val tap by rememberUpdatedState(onTap)
    Canvas(
        Modifier.fillMaxWidth().height(130.dp).pointerInput(total) {
            detectTapGestures { off -> tap((off.x / size.width * total).toLong().coerceIn(0, total)) }
        }
    ) {
        val w = size.width; val h = size.height
        peaks.forEachIndexed { i, pk ->
            val x = i * w / peaks.size
            val ph = (pk * h).coerceAtLeast(2f)
            drawLine(barColor, Offset(x, (h - ph) / 2), Offset(x, (h + ph) / 2), strokeWidth = (w / peaks.size).coerceAtLeast(1f))
        }
        cuts.forEach { c ->
            val x = c.toFloat() / total * w
            drawLine(cutColor, Offset(x, 0f), Offset(x, h), strokeWidth = 4f)
        }
    }
}
